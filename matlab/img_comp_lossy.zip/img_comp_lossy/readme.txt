1.upload all files to matlab

2.run rlc.m

dont forget to add the path to this directory where r store
