# Image-Compression-Using-RLC
Lossy image compression scheme based on Run Length Encoding on MATLAB. Performed wavelet decomposition using Haar filter and applied uniform quantization and then applied encoding on the converted array (1-D) of image pixels.
